/* Source-bound local FAQ fallback; no model/API requests or account access. */
(()=>{'use strict';
const copy={
'zh-Hant':['詢問助手','網站資料助手','網站資料模式 · AI 模型尚未接駁','你好，我可以幫你查閱回贈、優惠、遊戲及帳戶操作資訊。想了解甚麼？','輸入網站相關問題…','傳送','清除對話','關閉助手','查看相關頁面 ↗','我未能在網站資料中找到可靠答案。你可以換個說法，或使用下面的主題。帳戶個案請到協助頁整理問題；目前未接真人客服。','請勿輸入私鑰、助記詞、密碼或驗證碼。對話只保留於目前頁面，清除或離開即移除。','請不要在此提供敏感資料。我不會把這則內容加入對話；若已公開私鑰或助記詞，請按錢包供應商的安全指引處理。','你可以點選一個主題，或輸入問題。'],
en:['Ask the assistant','Site information assistant','Site information mode · AI model not connected','Hello. I can help you find cashback, offers, games and account information. What would you like to know?','Ask about this website…','Send','Clear conversation','Close assistant','View related page ↗','I could not find a reliable answer in the site information. Try rephrasing or choose a topic below. Use Assistance to draft an account issue; human support is not connected.','Do not enter private keys, seed phrases, passwords or verification codes. Conversation stays only on this page and is removed on clear or navigation.','Please do not share sensitive information here. I will not add this message to the conversation. If you exposed a private key or seed phrase, follow your wallet provider’s security guidance.','Choose a topic or type a question.'],
ko:['도우미에게 질문','사이트 정보 도우미','사이트 정보 모드 · AI 모델 미연결','안녕하세요. 캐시백·혜택·게임·계정 이용 정보를 찾아드립니다. 무엇이 궁금하신가요?','사이트 관련 질문 입력…','보내기','대화 지우기','도우미 닫기','관련 페이지 보기 ↗','사이트 자료에서 신뢰할 답변을 찾지 못했습니다. 다시 질문하거나 아래 주제를 선택하세요. 계정 문제는 도움말에서 정리할 수 있으나 상담원은 미연결입니다.','개인 키·복구 구문·비밀번호·인증 코드를 입력하지 마세요. 대화는 현재 페이지에만 남으며 지우거나 페이지를 이동하면 사라집니다.','민감한 정보를 공유하지 마세요. 이 메시지는 대화에 추가하지 않습니다. 개인 키나 복구 구문이 노출되었다면 지갑 제공업체의 보안 지침을 따르세요.','주제를 선택하거나 질문을 입력하세요.']};
const host=document.createElement('div');host.id='tycoon-concierge';host.dataset.userContent='';
host.innerHTML='<button class="tc-launch" type="button" aria-controls="tc-panel" aria-expanded="false"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 4h16v12H9l-5 4V4Z"/><path d="M8 8h8M8 12h5"/></svg><span></span></button><section id="tc-panel" class="tc-panel" role="dialog" aria-modal="false" aria-labelledby="tc-title" hidden><header class="tc-head"><div><small>TYC∞N CONCIERGE</small><h2 id="tc-title"></h2></div><button type="button" class="tc-close">×</button></header><p class="tc-mode"></p><div class="tc-log" role="log" aria-live="polite" aria-relevant="additions text" tabindex="0"></div><div class="tc-topics"></div><form class="tc-form"><label class="tc-label" for="tc-input"></label><div><input id="tc-input" type="text" maxlength="600" autocomplete="off"><button type="submit"></button></div></form><footer class="tc-foot"><p></p><button type="button" class="tc-clear"></button></footer></section>';
document.body.append(host);
const q=s=>host.querySelector(s),panel=q('.tc-panel'),launch=q('.tc-launch'),input=q('input'),log=q('.tc-log');
let messages=[],lastTopic=null;
const lang=()=>document.documentElement.lang||'zh-Hant';
function local(s){return lang()==='zh-Hans'&&typeof OpenCC!=='undefined'?OpenCC.Converter({from:'tw',to:'cn'})(s):s}
function words(){return (copy[lang()]||copy['zh-Hant']).map(local)}
function field(row,zh,en,ko){return local(row[lang()==='en'?en:lang()==='ko'?ko:zh])}
function add(tag,text,parent,cls){const e=document.createElement(tag);e.textContent=text;if(cls)e.className=cls;parent.append(e);return e}
function paint(){const c=words();q('.tc-launch span').textContent=c[0];launch.setAttribute('aria-label',c[0]);q('h2').textContent=c[1];q('.tc-mode').textContent=c[2];q('.tc-close').setAttribute('aria-label',c[7]);input.placeholder=c[4];q('.tc-label').textContent=c[4];q('[type=submit]').textContent=c[5];q('.tc-clear').textContent=c[6];q('.tc-foot p').textContent=c[10];log.replaceChildren();
add('p',c[3],log,'tc-answer');for(const m of messages){if(m.kind==='user')add('p',m.text,log,'tc-user');else{const e=add('div','',log,'tc-answer');if(m.topic){const r=window.TycoonConciergeData.find(r=>r[0]===m.topic);add('p',field(r,5,6,7),e);const a=add('a',c[8],e);a.href=r[8]}else add('p',c[m.code],e)}}
const topics=q('.tc-topics');topics.replaceChildren();for(const id of ['cashback','welcome','mahjong','wallet','support']){const r=window.TycoonConciergeData.find(r=>r[0]===id);const b=add('button',field(r,1,2,3),topics);b.type='button';b.dataset.topic=id}log.scrollTop=log.scrollHeight;
}
function toggle(open){panel.hidden=!open;launch.setAttribute('aria-expanded',String(open));if(open)input.focus();else launch.focus()}
function answer(text,forced){if(messages.length>=40)messages.splice(0,2);if(/0x[a-f0-9]{64}\b|(?:私鑰|私钥|private key|seed phrase|助記詞|助记词|密碼|密码|password|驗證碼|验证码|verification code|개인 키|비밀번호)\s*[:：=]\s*\S+/i.test(text)){messages.push({kind:'answer',code:11});paint();return}
messages.push({kind:'user',text});const lower=text.toLowerCase();let r=forced&&window.TycoonConciergeData.find(r=>r[0]===forced);
if(!r){const cn=lower;const matches=window.TycoonConciergeData.filter(r=>new RegExp(r[4],'i').test(cn));r=matches.find(r=>r[0]==='limits')||matches[0];if(!r&&lastTopic&&/^(那|咁|所以|還有|还有|then|what about|그럼)/i.test(lower))r=window.TycoonConciergeData.find(r=>r[0]===lastTopic)}
if(r){lastTopic=r[0];messages.push({kind:'answer',topic:r[0]})}else messages.push({kind:'answer',code:9});paint()}
launch.onclick=()=>toggle(panel.hidden);q('.tc-close').onclick=()=>toggle(false);
q('form').onsubmit=e=>{e.preventDefault();const text=input.value.trim();if(!text)return;input.value='';answer(text);input.focus()};
q('.tc-topics').onclick=e=>{const b=e.target.closest('[data-topic]');if(b)answer(b.textContent,b.dataset.topic)};
q('.tc-clear').onclick=()=>{messages=[];lastTopic=null;input.value='';paint();input.focus()};
host.addEventListener('keydown',e=>{if(e.key==='Escape'&&!panel.hidden){e.preventDefault();e.stopPropagation();toggle(false)}});
// The root is deliberately excluded from the site's global text translator.
let renderedLanguage=lang();
new MutationObserver(()=>{const next=lang();if(next===renderedLanguage)return;renderedLanguage=next;paint()}).observe(document.documentElement,{attributes:true,attributeFilter:['lang']});
paint();
})();
