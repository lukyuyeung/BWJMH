TYC∞N · 獨立 $BUNNY 社群網站
分享版本：2026-11-01；來源：網站 v19 / 0fbdfc24502c2c4aa25d6f8484a4aaeb853b51c8

website/ 包含目前網站所有 HTML、CSS、JavaScript 與圖片。
不包含 Git 紀錄、部署設定、登入憑證或私鑰。

預覽步驟
1. 解壓縮整個 ZIP，保留資料夾結構。
2. 在解壓縮資料夾的終端機執行：python preview.py
   （需要 Python 3；Windows 亦可執行 py preview.py）
3. 瀏覽器開啟 http://127.0.0.1:8080
4. 按 Ctrl+C 結束。
也可將 website/ 內檔案放到靜態網站主機。

這是現有網站的完整前端匯出。登入、真實資金及 AI 模型等後端服務尚未接駁。
日本麻雀是另一個獨立部署；本包保留原本線上入口，開啟遊戲仍需網絡，未包含另一專案的引擎及大型資源。
網站包含示範資料，不代表實際資金或獎勵。此社群與官方 $BUNNY 團隊無關。

公開網址：https://bunny-club-design-1029.almondcrab34.chatgpt.site
